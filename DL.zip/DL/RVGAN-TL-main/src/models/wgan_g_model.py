from .gan_g_model import GANGModel as WGANGModel
