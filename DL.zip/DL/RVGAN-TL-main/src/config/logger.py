fmt: str = '%(asctime)s [%(name)s] %(levelname)s: %(message)s'
level: int = 'INFO'
datefmt: str = '%Y-%m-%d %H:%M:%S'
