epochs: int = 500
lr: float = 1e-3
