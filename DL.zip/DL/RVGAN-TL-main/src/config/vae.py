epochs: int = 300

e_lr: float = 1e-3
d_lr: float = 1e-3
