epochs: int = 1000

d_loops: int = 3
g_loops: int = 1

d_lr: float = 2e-4
g_lr: float = 2e-4

hl_lambda = 1e-5

wgan_clamp = [-0.1, 0.1]

wgangp_lambda = 10
